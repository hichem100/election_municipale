#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "electorale.h"
#include <string.h>


int y;
int y1;
int y2;


void
on_centre_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{y=2;} 

}


void
on_gauche_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{y=3;} 

}


void
on_valid_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ty,*se,*da,*po,*nbr,*valid,*cn,*labelndl,*labelcin,*labelm1,*labelm2;
valid=lookup_widget(objet,"valid");
electorale A ;
int i;

int b=1;

ty = lookup_widget (objet,"ndl");
se = lookup_widget (objet,"id");
da = lookup_widget (objet,"id1");
po = lookup_widget (objet,"id2");
nbr = lookup_widget (objet,"nbr");
cn = lookup_widget (objet,"condi");




strcpy(A.nom_de_la_liste,gtk_entry_get_text(GTK_ENTRY(ty)));
strcpy(A.CIN,gtk_entry_get_text(GTK_ENTRY(se)));
strcpy(A.m1,gtk_entry_get_text(GTK_ENTRY(da)));
strcpy(A.m2,gtk_entry_get_text(GTK_ENTRY(po)));
A.membre=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(nbr));




labelndl=lookup_widget(objet,"saisiendl");
labelcin=lookup_widget(objet,"saisiecin");
labelm1=lookup_widget(objet,"saisiem1");
labelm2=lookup_widget(objet,"saisiem2");

if (y==1) 
strcpy(A.type_de_la_liste,"droit");
 if (y==2) 
strcpy(A.type_de_la_liste,"centre");
 if (y==3) 
strcpy(A.type_de_la_liste,"gauche");


if(strcmp(A.nom_de_la_liste,"")==0){
		 
          gtk_label_set_text(GTK_LABEL(labelndl),"saisir nom de la liste !");
b=0;
}
else {
		  
          gtk_label_set_text(GTK_LABEL(labelndl),"");
}

if(strcmp(A.CIN,"")==0){
		  
          gtk_label_set_text(GTK_LABEL(labelcin),"saisir CIN !");
b=0;
}
else {
		  
          gtk_label_set_text(GTK_LABEL(labelcin),"");
}

if(strcmp(A.m1,"")==0){
		  
          gtk_label_set_text(GTK_LABEL(labelm1),"saisir id membre 1 !");
b=0;
}
else {
		  
          gtk_label_set_text(GTK_LABEL(labelm1),"");
}
if(strcmp(A.m2,"")==0){
		  
          gtk_label_set_text(GTK_LABEL(labelm2),"saisir id membre 2 !");
b=0;
}
else {
		  
          gtk_label_set_text(GTK_LABEL(labelm2),"");
}




if(b==1){
ajouter(A,"liselect.txt");
}
 GtkWidget* p=lookup_widget(objet,"treeview1");
afficher_liste(p ,"liselect.txt");
GtkWidget* v=lookup_widget(objet,"treeview2");
afficher_liste1(v ,"vote.txt");
}


void
on_droit_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
 {y=1;} 

}


void
on_fasakh_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *dd;

char idd[20];

dd = lookup_widget (objet_graphique,"entry8");
strcpy(idd,gtk_entry_get_text(GTK_ENTRY(dd)));	

    supprimer(idd,"liselect.txt");
    supprimerr(idd,"vote.txt");	

GtkWidget* p=lookup_widget(objet_graphique,"treeview1");
	afficher_liste(p ,"liselect.txt");
GtkWidget* v=lookup_widget(objet_graphique,"treeview2");
	afficher_liste1(v ,"vote.txt");
}



void
on_lawej_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *dd,*nom_de_la_liste,*membre,*m1,*m2,*ty,*se,*da,*po,*nbr,*cen,*dro,*gau,*ine;
char idd[20];

int x=-1;
electorale e;

FILE *F;
	dd = lookup_widget (objet,"entry8");
	nom_de_la_liste = lookup_widget(objet,"saisiendl2");
	m1 = lookup_widget(objet, "saisiem11");
	m2 = lookup_widget(objet, "saisiem22");
	cen = lookup_widget(objet,"centre1");
	dro = lookup_widget(objet,"Droit1");
	gau = lookup_widget(objet,"gauche1");
	ine= lookup_widget(objet,"inexist");

	ty = lookup_widget (objet,"ndl2");
	se = lookup_widget (objet,"nbr2");
	da = lookup_widget (objet,"id11");
	po = lookup_widget (objet,"id12");




strcpy(idd,gtk_entry_get_text(GTK_ENTRY(dd)));

F = fopen ("liselect.txt", "r");

if (F!=NULL)
 {
  while (fscanf (F,"%s %d %s %s %s %s\n",e.nom_de_la_liste,&e.membre,e.CIN,e.m1,e.m2,e.type_de_la_liste) != EOF)
  {
  
    if (strcmp (idd,e.CIN) == 0)
      {
      x=1;
      } 
     } 
    
     fclose (F);
  }

if(x==-1)
{
gtk_label_set_text(GTK_LABEL(ine),"CIN inexistant"); 
gtk_label_set_text(GTK_LABEL(ty),"");
//gtk_label_set_text(GTK_LABEL(se),"");
gtk_label_set_text(GTK_LABEL(da),"");
gtk_entry_set_text(GTK_LABEL(po),"");
}else
{
    electorale A= chercher("liselect.txt",idd);
	gtk_label_set_text(GTK_LABEL(ine),"");
	gtk_label_set_text(GTK_LABEL(nom_de_la_liste),A.nom_de_la_liste);
	gtk_label_set_text(GTK_LABEL(m1),A.m1);
	gtk_label_set_text(GTK_LABEL(m2),A.m2);
	gtk_spin_button_set_value(se,A.membre);

	gtk_entry_set_text(GTK_LABEL(ty),A.nom_de_la_liste);
	gtk_entry_set_text(GTK_LABEL(da),A.m1);
	gtk_entry_set_text(GTK_LABEL(po),A.m2);
	if (strcmp(A.type_de_la_liste, "droit") == 0) 
{
  gtk_toggle_button_set_active(GTK_RADIO_BUTTON(dro), TRUE);
  
} else if (strcmp(A.type_de_la_liste, "centre") == 0) 
{
  gtk_toggle_button_set_active(GTK_RADIO_BUTTON(cen), TRUE);
  
} else if (strcmp(A.type_de_la_liste, "gauche") == 0) 
{
  gtk_toggle_button_set_active(GTK_RADIO_BUTTON(gau), TRUE);
  
} 
}
}





void
on_badel_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *dd,*ty,*se,*da,*nb,*lb;

char idd [20] ;
electorale U ;
voteliste V;

dd = lookup_widget (objet_graphique,"entry8");
ty = lookup_widget (objet_graphique,"ndl2");
se = lookup_widget (objet_graphique,"id11");
da = lookup_widget (objet_graphique,"id12");
nb = lookup_widget (objet_graphique,"nbr2");



strcpy (U.type_de_la_liste,"");
if (y1==1) 
strcpy(U.type_de_la_liste,"gauche");
 if (y1==2) 
strcpy(U.type_de_la_liste,"centre");
 if (y1==3) 
strcpy(U.type_de_la_liste,"droit");



strcpy(idd,gtk_entry_get_text(GTK_ENTRY(dd)));

U.membre=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(nb));
strcpy(U.CIN,gtk_entry_get_text(GTK_ENTRY(dd)));
strcpy(U.nom_de_la_liste,gtk_entry_get_text(GTK_ENTRY(ty)));
strcpy(U.m1,gtk_entry_get_text(GTK_ENTRY(se)));
strcpy(U.m2,gtk_entry_get_text(GTK_ENTRY(da)));
strcpy(V.nom_de_la_liste,gtk_entry_get_text(GTK_ENTRY(ty)));
strcpy(V.CIN,gtk_entry_get_text(GTK_ENTRY(dd)));

modifier(idd,U,"liselect.txt");
modifierr(idd,V,"vote.txt");

 GtkWidget* p=lookup_widget(objet_graphique,"treeview1");
afficher_liste(p ,"liselect.txt");
GtkWidget* v=lookup_widget(objet_graphique,"treeview2");
afficher_liste1(v ,"vote.txt");
}


void
on_condi1_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{

}

void
on_act_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkTreeModel     *model;
        GtkTreeSelection *selection;
        GtkTreeIter iter;
        GtkWidget* p=lookup_widget(objet,"treeview1");
	gchar *nom_de_la_liste;
        gchar *membre;
        gchar *CIN;
        gchar *m1;
  	gchar *m2;
        gchar *type_de_la_liste;
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&nom_de_la_liste,1,&membre,2,&CIN,3,&m1,4,&m2,5,&type_de_la_liste,-1);
  	
               	
}
afficher_liste(p ,"liselect.txt");
}

void
on_tri_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data)
{


GtkTreeModel     *model;
        GtkTreeSelection *selection;
        GtkTreeIter iter;
        GtkWidget* v=lookup_widget(objet,"treeview2");
	gchar *nom_de_la_liste;
        gchar *vote;
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(v));
if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&nom_de_la_liste,1,vote,-1);
}
afficher_liste1(v,"vote.txt");
ordre("vote.txt");
}


void
on_valid2_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
voteliste v;
GtkWidget *vote;
GtkWidget *nom_de_la_liste,*nbv;
vote=lookup_widget(objet,"valid1");
nom_de_la_liste=lookup_widget(objet,"combobox1");

FILE * f=fopen("vote.txt","r");
if(f!=NULL)
{	while((fscanf(f,"%s %s %d",v.nom_de_la_liste,v.CIN,&v.nbv))!=EOF)
	{
		gtk_combo_box_append_text(GTK_COMBO_BOX(nom_de_la_liste),(v.nom_de_la_liste));
	}
}
fclose(f);
}


void
on_votee_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
electorale e;
GtkWidget *vote;
GtkWidget *nom_de_la_liste;
vote=lookup_widget(objet,"votee");
nom_de_la_liste=lookup_widget(objet,"combobox1");
strcpy(e.nom_de_la_liste,gtk_combo_box_get_active_text(GTK_COMBO_BOX(nom_de_la_liste)));
voter("vote.txt",e.nom_de_la_liste);

}


void
on_condi_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
 {y2=1;}
}


void
on_gauche1_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
 {y1=1;}
}


void
on_centre1_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
 {y1=2;}
}


void
on_droite1_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
 {y1=3;}
}

