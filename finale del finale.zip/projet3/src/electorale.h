#ifndef ELECTORALE_H_INCLUDED
#define ELECTORALE_H_INCLUDED
#include <stdio.h>
#include <string.h>
#include<gtk/gtk.h>
typedef struct
{
  char nom_de_la_liste [20] ;
  int membre ;
  char CIN [20] ;
  char m1 [20];
  char m2 [20];
  char type_de_la_liste [20]  ;
    
}electorale;

typedef struct
{ char nom_de_la_liste [20] ;
  char CIN [20];
 int nbv;
}voteliste;


int ajouter(electorale e , char liselect []);
int modifier(char * CIN, electorale nouv, char * liselect);
int modifierr(char * CIN, voteliste nouv, char * liselect);
int supprimer(char * CIN,char * liselect);
int supprimerr(char * CIN,char * liselect);
electorale chercher(char * liselect , char * cin );
int voter (char * vote,char nom_de_la_liste[]);
int ordre (char * vote);
void afficher_liste (GtkWidget *treeview1 ,char *l);
void afficher_liste1 (GtkWidget *treeview2 ,char *S);


#endif // ELECTORALE_H_INCLUDED





