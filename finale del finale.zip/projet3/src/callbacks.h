#include <gtk/gtk.h>


void
on_centre_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_gauche_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_valid_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_droit_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_fasakh_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_lawej_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_badel_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Droit1_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_centre1_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_gauche1_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_condi1_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_act_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_tri_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_valid2_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_votee_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_condi_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_gauche1_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_centre1_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_droite1_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
