#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include "electorale.h"
#include<stdio.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <string.h>
#include <gtk/gtk.h>

int ajouter(electorale e , char liselect [])
{
    FILE * f=fopen(liselect, "a");
    FILE * f2=fopen("vote.txt", "a");
    if(f!=NULL && f2!=NULL)
    {
        fprintf(f,"%s %d %s %s %s %s\n",e.nom_de_la_liste,e.membre,e.CIN,e.m1,e.m2,e.type_de_la_liste);
        fprintf(f2,"%s %s %d \n",e.nom_de_la_liste,e.CIN,0);
        fclose(f);
	fclose(f2);
        return 1;
    }
    else return 0;
}

int modifier(char * CIN, electorale nouv, char * liselect)
{
electorale e;
    FILE * f=fopen(liselect, "r");
    FILE * f2 =fopen("liste.txt", "w");
    if(f==NULL || f2==NULL)
return 0;
else
    {
while(fscanf(f,"%s %d %s %s %s %s\n",e.nom_de_la_liste,&e.membre,e.CIN,e.m1,e.m2,e.type_de_la_liste)!=EOF)
{
if(strcmp(e.CIN,CIN)!=0)
        fprintf(f2,"%s %d %s %s %s %s\n",e.nom_de_la_liste,e.membre,e.CIN,e.m1,e.m2,e.type_de_la_liste);
else

  fprintf(f2,"%s %d %s %s %s %s\n",nouv.nom_de_la_liste,nouv.membre,nouv.CIN,nouv.m1,nouv.m2,nouv.type_de_la_liste);

}
        fclose(f);
        fclose(f2);
remove(liselect);
rename("liste.txt", liselect);
        return 1;
    }
 
}

int modifierr(char * CIN, voteliste nouv, char * liselect)
{
voteliste v;
    FILE * f=fopen(liselect, "r");
    FILE * f2 =fopen("liste.txt", "w");
    if(f==NULL || f2==NULL)
return 0;
else
    {
while(fscanf(f,"%s %s %d\n",v.nom_de_la_liste,v.CIN,&v.nbv)!=EOF)
{
if(strcmp(v.CIN,CIN)!=0)
        fprintf(f2,"%s %s %d\n",v.nom_de_la_liste,v.CIN,v.nbv);
else

  fprintf(f2,"%s %s %d\n",nouv.nom_de_la_liste,nouv.CIN,v.nbv);

}
        fclose(f);
        fclose(f2);
remove(liselect);
rename("liste.txt", liselect);
        return 1;
    }
 
}

int supprimer(char * CIN, char * liselect)
{
electorale e;
    FILE * f=fopen(liselect, "r");
    FILE * f2 =fopen("liste.txt", "w+");
    if(f==NULL || f2==NULL)
return 0;
else
    {
while(fscanf(f,"%s %d %s %s %s %s\n",e.nom_de_la_liste,&e.membre,e.CIN,e.m1,e.m2,e.type_de_la_liste)!=EOF)        

{
if(strcmp(e.CIN,CIN)!=0)
        fprintf(f2,"%s %d %s %s %s %s\n",e.nom_de_la_liste,e.membre,e.CIN,e.m1,e.m2,e.type_de_la_liste);

}
        fclose(f);
        fclose(f2);
remove(liselect);
rename("liste.txt", liselect);
        return 1;
    }
}

int supprimerr(char * CIN, char * liselect)
{
voteliste v;
    FILE * f=fopen(liselect, "r");
    FILE * f2 =fopen("liste.txt", "w+");
    if(f==NULL || f2==NULL)
return 0;
else
    {
while(fscanf(f,"%s %s %d\n",v.nom_de_la_liste,v.CIN,&v.nbv)!=EOF)        

{
if(strcmp(v.CIN,CIN)!=0)
        fprintf(f2,"%s %s %d\n",v.nom_de_la_liste,v.CIN,v.nbv);

}
        fclose(f);
        fclose(f2);
remove(liselect);
rename("liste.txt", liselect);
        return 1;
    }
}

electorale chercher(char * liselect , char * cin )

{
    electorale e;
    int tr;
    FILE * f=fopen("liselect.txt", "r");
     tr=0;
    if(f!=NULL)
    {
        while(tr==0 && fscanf(f,"%s %d %s %s %s %s\n",e.nom_de_la_liste,&e.membre,e.CIN,e.m1,e.m2,e.type_de_la_liste)!=EOF)
        {
            if(strcmp(e.CIN,cin)==0)
                tr=1;
        }
    }
    fclose(f);
    if(tr==0)
        strcpy(e.CIN,"-1");
    return e;}
int voter(char * vote, char nom_de_la_liste[])
{
voteliste v;
    FILE * f=fopen(vote, "r");
    FILE * f2 =fopen("liste.txt", "w");
    if(f==NULL || f2==NULL)
return 0;
else
    {
while(fscanf(f,"%s %s %d \n",v.nom_de_la_liste,v.CIN,&v.nbv)!=EOF)
{
if(strcmp(v.nom_de_la_liste,nom_de_la_liste)!=0)
fprintf(f2,"%s %s %d \n",v.nom_de_la_liste,v.CIN,v.nbv);
else
{v.nbv++;
 fprintf(f2,"%s %s %d \n",v.nom_de_la_liste,v.CIN,v.nbv);
}}
	fclose(f);
        fclose(f2);
remove(vote);
rename("liste.txt", vote);
        return 1;
    }
}

int ordre (char * vote)
{
int max=0;
voteliste tampon;
voteliste t[100];
voteliste v;
int y=0;
int x=0;
int i,j;
    FILE * f=fopen(vote, "r");
    FILE * f2 =fopen("liste.txt", "w");
    if(f==NULL || f2==NULL)
return 0;
else
    {
while(fscanf(f,"%s %s %d \n",v.nom_de_la_liste,v.CIN,&v.nbv)!=EOF)
{
t[y]=v;
y++;
}
for (i=0;i<y-1;i++)

{

max=i ;

for (j=i+1;j<y;j++) 

{

if (t[j].nbv>t[max].nbv)

max=j;

}

tampon=t[i];

t[i]=t[max];

t[max]=tampon;

}
while(x<y)
{
fprintf(f2,"%s %s %d \n",t[x].nom_de_la_liste,t[x].CIN,t[x].nbv);
x++;
}
}
	fclose(f);
        fclose(f2);
remove(vote);
rename("liste.txt", vote);
return 1;
}

void afficher_liste (GtkWidget *treeview1, char*l )

{




GtkListStore *adstore;/*creation du modele de type liste*/
adstore=NULL;
GtkTreeViewColumn *adcolumn;/*visualisation des colonnes*/
GtkCellRenderer *cellad;/*afficheur de cellule(text,image..)*/

FILE *f;
adstore=gtk_tree_view_get_model(treeview1);



	char nom_de_la_liste [20] ;
	char membre [20] ;
	char CIN [20] ;
	char m1 [20];
	char m2 [20];
	char type_de_la_liste [20];
	int k=0;

     
     

	/* Creation de la 1ere colonne */
	if(adstore==NULL)
	{cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("nom_de_la_liste",
                                                            cellad,
                                                            "text", 0,
                                                            NULL);


        /* Ajouter la 1er colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);


	/* Creation de la 2eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("membre",
                                                            cellad,
                                                            "text", 1,
                                                            NULL);
	/* Ajouter la 2emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);




	/* Creation de la 4eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("CIN",
                                                            cellad,
                                                            "text", 2,
                                                            NULL);
	/* Ajouter la 4emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

	/* Creation de la 5eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("m1",
                                                            cellad,
                                                            "text", 3,
                                                            NULL);
	/* Ajouter la 5emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);


        /* Creation de la 5eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("m2",
                                                            cellad,
                                                            "text", 4,
                                                            NULL);
	/* Ajouter la 5emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

	/* Creation de la 3eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("type_de_la_liste",
                                                            cellad,
                                                            "text", 5,
                                                            NULL);

	/* Ajouter la 3emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);


	}
   /* Creation du modele */
        adstore = gtk_list_store_new(6,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING);
   /* Insertion des elements */
        f=fopen(l,"r");
while(fscanf(f,"%s %s %s %s %s %s\n",nom_de_la_liste,membre,CIN,m1,m2,type_de_la_liste)!= EOF)
        {GtkTreeIter pIter;

         /* Creation de la nouvelle ligne */
         gtk_list_store_append(adstore, &pIter);
         /* Mise a jour des donnees */
         gtk_list_store_set(adstore, &pIter,
                            0,nom_de_la_liste,
                            1,membre,
                            2,CIN,
                            3,m1,
                            4,m2,
			    5,type_de_la_liste,
                            -1);}
        fclose(f);


 	gtk_tree_view_set_model ( GTK_TREE_VIEW (treeview1),
                                  GTK_TREE_MODEL(adstore)  );
g_object_unref(adstore);
}




void afficher_liste1 (GtkWidget *treeview2 ,char *S)
{




GtkListStore *adstore;/*creation du modele de type liste*/
adstore=NULL;
GtkTreeViewColumn *adcolumn;/*visualisation des colonnes*/
GtkCellRenderer *cellad;/*afficheur de cellule(text,image..)*/

FILE *f;
adstore=gtk_tree_view_get_model(treeview2);



	char nom_de_la_liste [20] ;
	char vote [20] ;
	char CIN [20];

/* Creation de la 1ere colonne */
	if(adstore==NULL)
	{cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("nom_de_la_liste",
                                                            cellad,
                                                            "text", 0,
                                                            NULL);


        /* Ajouter la 1er colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview2), adcolumn);


	/* Creation de la 2eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("vote",
                                                            cellad,
                                                            "text", 1,
                                                            NULL);
	/* Ajouter la 2emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview2), adcolumn);

}
/* Creation du modele */
        adstore = gtk_list_store_new(2,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING);
   /* Insertion des elements */
        f=fopen(S,"r");
while(fscanf(f,"%s %s %s \n",nom_de_la_liste,CIN,vote)!= EOF)
        {GtkTreeIter pIter;

         /* Creation de la nouvelle ligne */
         gtk_list_store_append(adstore, &pIter);
         /* Mise a jour des donnees */
         gtk_list_store_set(adstore, &pIter,
                            0,nom_de_la_liste,
                            1,vote,                         
                            -1);}
        fclose(f);


 	gtk_tree_view_set_model ( GTK_TREE_VIEW (treeview2),
                                  GTK_TREE_MODEL(adstore)  );
g_object_unref(adstore);
}


